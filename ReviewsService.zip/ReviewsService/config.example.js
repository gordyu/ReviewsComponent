module.exports = {
  TOKEN: 'YOUR TOKEN HERE'
};