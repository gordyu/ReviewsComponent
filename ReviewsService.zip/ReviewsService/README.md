# ReviewsComponent

Try reading the package.json.# ReviewsComponent
